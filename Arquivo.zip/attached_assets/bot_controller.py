
import discord
from discord.ext import commands
from discord import app_commands
import yaml
import json
import os
import asyncio
import discum

class TokenButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Gerenciar Tokens", style=discord.ButtonStyle.primary, custom_id="token")
    
    async def callback(self, interaction: discord.Interaction):
        with open('config/tokens.txt', 'r') as f:
            tokens = f.read().splitlines()
        
        embed = discord.Embed(
            title="🔑 Gerenciamento de Tokens",
            description="Gerencie seus tokens abaixo:",
            color=discord.Color.blue()
        )
        
        for i, token in enumerate(tokens, 1):
            masked_token = f"{token[:20]}...{token[-20:]}"
            embed.add_field(name=f"Token {i}", value=f"`{masked_token}`", inline=False)
            
        buttons = discord.ui.View()
        buttons.add_item(AddTokenButton())
        buttons.add_item(RemoveTokenButton())
        buttons.add_item(ClearTokensButton())
        
        await interaction.response.send_message(embed=embed, view=buttons, ephemeral=True)

class AddTokenButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Adicionar Token", style=discord.ButtonStyle.success, custom_id="add_token")
    
    async def callback(self, interaction: discord.Interaction):
        modal = TokenModal()
        await interaction.response.send_modal(modal)

class RemoveTokenButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Remover Token", style=discord.ButtonStyle.danger, custom_id="remove_token")
    
    async def callback(self, interaction: discord.Interaction):
        modal = RemoveTokenModal()
        await interaction.response.send_modal(modal)

class ClearTokensButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Limpar Todos", style=discord.ButtonStyle.danger, custom_id="clear_tokens")
    
    async def callback(self, interaction: discord.Interaction):
        with open('config/tokens.txt', 'w') as f:
            f.write('')
        embed = discord.Embed(
            title="🗑️ Tokens Limpos",
            description="Todos os tokens foram removidos com sucesso!",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class MessageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Gerenciar Mensagem", style=discord.ButtonStyle.success, custom_id="message")
    
    async def callback(self, interaction: discord.Interaction):
        view = MessagePanel()
        embed = discord.Embed(
            title="📝 Gerenciamento de Mensagem",
            description="Use os botões abaixo para gerenciar a mensagem do bot:",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class SettingsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Configurações", style=discord.ButtonStyle.secondary, custom_id="settings", disabled=True)
    
    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

class StartButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Iniciar", style=discord.ButtonStyle.success, custom_id="start")
    
    async def callback(self, interaction: discord.Interaction):
        tokens = open('config/tokens.txt').read().splitlines()
        for token in tokens:
            os.system(f"start python main.py {token}")
            await asyncio.sleep(1)
        await interaction.response.send_message(f"✅ Sistema iniciado com {len(tokens)} tokens!", ephemeral=True)

class JoinServerButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Entrar em Servidor", style=discord.ButtonStyle.success, custom_id="join_server")
    
    async def callback(self, interaction: discord.Interaction):
        modal = JoinServerModal()
        await interaction.response.send_modal(modal)

class JoinServerModal(discord.ui.Modal, title="Entrar em Servidor"):
    invite = discord.ui.TextInput(
        label="Link do Servidor",
        placeholder="discord.gg/exemplo",
        required=True,
        max_length=30
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        invite_code = self.invite.value.split("/")[-1]
        with open('config/tokens.txt', 'r') as f:
            tokens = [t for t in f.read().splitlines() if t]
        
        success = 0
        for token in tokens:
            try:
                bot = discum.Client(token=token, log=False)
                join = bot.joinGuild(invite_code, location="join guild", wait=1)
                
                if join.status_code == 200:
                    success += 1
                    guild_id = join.json()["guild"]["id"]
                    print(f"Joined server successfully with token {success}")
                    
                    # Subscribe to guild events
                    bot.gateway.subscribeToGuildEvents(wait=1, guildIDs=[guild_id], token=token)
                    
                    # Wait for gateway events
                    await asyncio.sleep(5)
                    
                    # Get channel list and handle verification
                    channels = bot.getGuildChannels(guild_id)
                    
                    for channel in channels.json():
                        if any(word in channel["name"].lower() for word in ["verify", "captcha", "rules", "welcome"]):
                            try:
                                messages = bot.getMessages(channel["id"], num=20)
                                for msg in messages.json():
                                    if "components" in msg and msg.get("components"):
                                        for component in msg["components"]:
                                            if component.get("type") == 2: # Button
                                                bot.click(
                                                    msg["author"]["id"],
                                                    channel["id"],
                                                    msg["id"],
                                                    0,
                                                    guild_id
                                                )
                                                await asyncio.sleep(3)
                            except Exception as e:
                                print(f"Error in verification process: {e}")
                                continue
                    
                    await asyncio.sleep(3)
            except Exception as e:
                print(f"Failed to join with token: {e}")
                continue
        
        embed = discord.Embed(
            title="✅ Entrada em Servidor",
            description=f"**{success}** de **{len(tokens)}** tokens entraram no servidor com sucesso!",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class StopButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Parar Instâncias", style=discord.ButtonStyle.danger, custom_id="stop")
    
    async def callback(self, interaction: discord.Interaction):
        try:
            os.system("taskkill /f /im python.exe")
            embed = discord.Embed(
                title="🛑 Sistema Parado",
                description="Todas as instâncias foram encerradas com sucesso!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Erro",
                description=f"Erro ao parar sistema: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class BotController(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.all())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()

client = BotController()

@client.event
async def on_ready():
    print(f'Bot Controller está online como {client.user.name}')

@client.tree.command(name="painel", description="Painel de controle do bot")
async def painel(interaction: discord.Interaction):
    with open('config/tokens.txt', 'r') as f:
        token_count = len(f.readlines())
    
    with open('config/settings.yaml', 'r') as f:
        settings = yaml.safe_load(f)
    
    ping = round(client.latency * 1000)
    status = "🟢 Online" if ping < 200 else "🟡 Instável" if ping < 500 else "🔴 Alto Delay"

    embed = discord.Embed(
        title="🤖 Painel de Controle do Bot",
        description=f"Sistema de controle e monitoramento\n\n**Status**: {status}\n**Ping**: `{ping}ms`\n**Tokens**: `{token_count}`\n\n**Configurações Atuais**:\n```yaml\nCooldown: {settings['dm_cooldown']}s\nMensagem Auto.: {settings['dm_reply']}\nDigitando: {settings['dm_typing']}\nReação: {settings['dm_reaction']}\n```",
        color=discord.Color.blue()
    )
    embed.set_footer(text=f"Solicitado por {interaction.user.name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
    
    buttons = discord.ui.View()
    buttons.add_item(TokenButton())
    buttons.add_item(MessageButton())
    buttons.add_item(SettingsButton())
    buttons.add_item(JoinServerButton())
    buttons.add_item(StartButton())
    buttons.add_item(StopButton())
    
    await interaction.response.send_message(embed=embed, view=buttons, ephemeral=True)

class TokenModal(discord.ui.Modal, title="Adicionar Token"):
    token = discord.ui.TextInput(label="Token", placeholder="Digite o token aqui...")
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            token = self.token.value.strip()
            with open('config/tokens.txt', 'r') as f:
                existing_tokens = [t for t in f.read().splitlines() if t]
            
            if token in existing_tokens:
                embed = discord.Embed(
                    title="❌ Erro",
                    description="Este token já existe na lista!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
                
            with open('config/tokens.txt', 'a') as f:
                f.write(f'\n{token}')
            
            embed = discord.Embed(
                title="✅ Token Adicionado",
                description=f"Token adicionado com sucesso!\nToken: `{token[:20]}...{token[-20:]}`",
                color=discord.Color.green()
            )
            embed.add_field(name="Total de Tokens", value=f"`{len(existing_tokens) + 1}`")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Erro",
                description=f"Erro ao adicionar token: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class RemoveTokenModal(discord.ui.Modal, title="Remover Token"):
    token = discord.ui.TextInput(label="Token", placeholder="Digite o token para remover...")
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            token_to_remove = self.token.value.strip()
            with open('config/tokens.txt', 'r') as f:
                tokens = [t for t in f.read().splitlines() if t]
            
            if token_to_remove not in tokens:
                embed = discord.Embed(
                    title="❌ Erro",
                    description="Token não encontrado na lista!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            tokens.remove(token_to_remove)
            with open('config/tokens.txt', 'w') as f:
                f.write('\n'.join(tokens))
            
            embed = discord.Embed(
                title="✅ Token Removido",
                description=f"Token removido com sucesso!\nToken: `{token_to_remove[:20]}...{token_to_remove[-20:]}`",
                color=discord.Color.green()
            )
            embed.add_field(name="Total de Tokens", value=f"`{len(tokens)}`")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Erro",
                description=f"Erro ao remover token: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class MessagePanel(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.load_current_message()

    def load_current_message(self):
        try:
            with open('config/message.txt', 'r', encoding='utf-8') as f:
                self.current_message = f.read()
        except:
            self.current_message = "Nenhuma mensagem definida"

    @discord.ui.button(label="Ver Mensagem Atual", style=discord.ButtonStyle.secondary)
    async def view_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="📝 Mensagem Atual", description=self.current_message, color=discord.Color.blue())
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="Nova Mensagem", style=discord.ButtonStyle.success)
    async def new_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = MessageModal()
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Editar", style=discord.ButtonStyle.primary)
    async def edit_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = MessageModal(self.current_message)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Deletar", style=discord.ButtonStyle.danger)
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        with open('config/message.txt', 'w', encoding='utf-8') as f:
            f.write('')
        self.current_message = "Nenhuma mensagem definida"
        await interaction.response.send_message("✅ Mensagem deletada com sucesso!", ephemeral=True)

class MessageModal(discord.ui.Modal, title="Gerenciar Mensagem"):
    def __init__(self, current_message=""):
        super().__init__()
        self.message = discord.ui.TextInput(
            label="Mensagem",
            style=discord.TextStyle.paragraph,
            placeholder="Digite a mensagem aqui...",
            default=current_message
        )
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        with open('config/message.txt', 'w', encoding='utf-8') as f:
            f.write(self.message.value)
        await interaction.response.send_message("✅ Mensagem atualizada com sucesso!", ephemeral=True)

class SettingsModal(discord.ui.Modal, title="Configurações"):
    def __init__(self):
        super().__init__()
        with open('config/settings.yaml', 'r', encoding='utf-8') as f:
            current_settings = yaml.safe_load(f)
        
        self.settings = discord.ui.TextInput(
            label="Configurações", 
            style=discord.TextStyle.paragraph,
            placeholder='Insira as configurações em YAML',
            default=f"dm_cooldown: {current_settings.get('dm_cooldown', 3)}\nmask: {current_settings.get('mask', 'https://discord.gg/exemplo')}"
        )
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            settings_dict = yaml.safe_load(self.settings.value)
            if not settings_dict:
                raise ValueError("Settings cannot be empty")
            
            with open('config/settings.yaml', 'r', encoding='utf-8') as f:
                current_settings = yaml.safe_load(f)
            
            current_settings.update(settings_dict)
            
            with open('config/settings.yaml', 'w', encoding='utf-8') as f:
                yaml.dump(current_settings, f)
                
            await interaction.response.send_message("✅ Configurações atualizadas com sucesso!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao atualizar configurações: {str(e)}", ephemeral=True)

client.run('MTM0MjYzNjU1NTk3Nzc1Njc2NQ.GMYDcJ.Q9qnqKwt8ATaH_0DcxAq3pZ0G-g7RnjmFeejX0')
