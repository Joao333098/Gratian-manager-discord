# Updated MessagePanel with delete/edit/create buttons
import discum, threading, yaml, os, asyncio, random, base64, time, sys, json, requests, io
from api.database import Manager
from api.colors import colors
import discord
from discord.ext import commands
from discord import app_commands

print("Iniciando ...")

class EmojiManager:
    def __init__(self, guild):
        self.guild = guild
        self.emoji_urls = {
            "tokens": "https://cdn.discordapp.com/emojis/1184123456789012345.png",  # Ícone de chave moderna
            "message": "https://cdn.discordapp.com/emojis/1184123456789012346.png",  # Ícone de mensagem moderna
            "settings": "https://cdn.discordapp.com/emojis/1184123456789012347.png",  # Ícone de engrenagem moderna
            "logs": "https://cdn.discordapp.com/emojis/1184123456789012348.png",  # Ícone de gráfico moderno
            "permissions": "https://cdn.discordapp.com/emojis/1184123456789012349.png",  # Ícone de escudo moderno
            "start": "https://cdn.discordapp.com/emojis/1184123456789012350.png",  # Ícone de play moderno
            "stop": "https://cdn.discordapp.com/emojis/1184123456789012351.png",  # Ícone de stop moderno
            "back": "https://cdn.discordapp.com/emojis/1184123456789012352.png",  # Ícone de voltar moderno
        }
        # URLs alternativas de emojis públicos
        self.backup_urls = {
            "tokens": "https://i.imgur.com/vKjPy7q.png",  # Chave dourada
            "message": "https://i.imgur.com/8mGhT3w.png",  # Balão de chat
            "settings": "https://i.imgur.com/nF4mX8s.png",  # Engrenagem azul
            "logs": "https://i.imgur.com/kL3nM7t.png",  # Gráfico
            "permissions": "https://i.imgur.com/xR9sK4p.png",  # Escudo
            "start": "https://i.imgur.com/yH6vN2w.png",  # Play verde
            "stop": "https://i.imgur.com/zQ8tP5x.png",  # Stop vermelho
            "back": "https://i.imgur.com/mK7nL9q.png",  # Seta voltar
        }
        self.created_emojis = {}
    
    async def download_image(self, url):
        """Baixa uma imagem da URL"""
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                return response.content
            return None
        except:
            return None
    
    async def create_emoji(self, name, url):
        """Cria um emoji customizado no servidor"""
        try:
            # Tentar URL principal
            image_data = await self.download_image(url)
            
            # Se falhar, tentar URL backup
            if not image_data and name in self.backup_urls:
                image_data = await self.download_image(self.backup_urls[name])
            
            if not image_data:
                return None
            
            # Criar emoji no servidor
            emoji = await self.guild.create_custom_emoji(
                name=f"panel_{name}",
                image=image_data,
                reason="Emoji para painel de controle"
            )
            
            self.created_emojis[name] = str(emoji)
            return str(emoji)
            
        except discord.HTTPException as e:
            stats.add_log(f"Erro ao criar emoji {name}: {str(e)}")
            return None
        except Exception as e:
            stats.add_log(f"Erro geral ao criar emoji {name}: {str(e)}")
            return None
    
    async def get_emoji(self, name):
        """Obtém um emoji, criando se necessário"""
        # Se já temos o emoji, retornar
        if name in self.created_emojis:
            return self.created_emojis[name]
        
        # Verificar se emoji já existe no servidor
        for emoji in self.guild.emojis:
            if emoji.name == f"panel_{name}":
                self.created_emojis[name] = str(emoji)
                return str(emoji)
        
        # Criar novo emoji
        emoji_str = await self.create_emoji(name, self.emoji_urls.get(name, ""))
        if emoji_str:
            return emoji_str
        
        # Fallback para emoji padrão
        fallback_emojis = {
            "tokens": "🗝️",
            "message": "💬", 
            "settings": "⚙️",
            "logs": "📊",
            "permissions": "🔒",
            "start": "🚀",
            "stop": "🛑",
            "back": "🔙"
        }
        return fallback_emojis.get(name, "⚙️")
    
    async def setup_all_emojis(self):
        """Configura todos os emojis necessários"""
        stats.add_log("Configurando emojis customizados...")
        
        for name in self.emoji_urls.keys():
            emoji = await self.get_emoji(name)
            stats.add_log(f"Emoji {name}: {emoji}")
        
        stats.add_log("Configuração de emojis concluída!")

# Instância global do gerenciador de emojis
emoji_manager = None

def get_id(token):
    """Extract the user ID from a Discord token"""
    try:
        if not token or '.' not in token:
            raise ValueError("Token inválido")
        
        # Pegar a primeira parte do token
        token_part = token.split('.')[0]
        
        # Adicionar padding se necessário
        missing_padding = len(token_part) % 4
        if missing_padding:
            token_part += '=' * (4 - missing_padding)
        
        # Decodificar base64
        decoded = base64.b64decode(token_part).decode('utf-8')
        
        # Verificar se é um ID válido (números)
        if not decoded.isdigit():
            raise ValueError("ID decodificado não é numérico")
            
        return decoded
    except Exception as e:
        raise ValueError(f"Erro ao extrair ID do token: {str(e)}")

try:
    with open('config/settings.yaml', encoding='utf-8') as f:
        settings = yaml.load(f, Loader=yaml.FullLoader)
        settings['_'] = "hakeatos"
        f.close()

    with open('config/message.txt', encoding='utf-8') as f:
        settings['message'] = f.read()
        f.close()

    if settings['mask_link']:
        for line in settings['message'].split():
            if "https://discord.gg/aresrp" in line:
                new_link = settings['mask']
                new_message = settings['message'].replace(line, f"<{new_link}> ||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||")
                settings['message'] = new_message

    tokens = sys.argv
    tokens.remove(tokens[0])
    if len(tokens) == 0: 
        tokens = open('config/tokens.txt').read().splitlines()
    tokens_index = {}

    for token in tokens: 
        tokens_index[token] = {'is_sleeping': False, 'is_rate_limit': False, 'reply_users_sience': {}}

    db = Manager(settings['mongo_db_url'])

except Exception as e:
    print(f'Erro: {e}')

import threading

def validate_token_api(token):
    """Validar token via API do Discord"""
    if not token or len(token) < 20:
        return False
    
    headers = {
        'authorization': token,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'x-discord-locale': 'en-US',
        'x-debug-options': 'bugReporterEnabled'
    }
    
    try:
        # Primeiro, validar o formato do token
        try:
            user_id = get_id(token)
            if not user_id.isdigit():
                return False
        except:
            return False
        
        # Tentar fazer requisição para validar
        response = requests.get('https://discord.com/api/v10/users/@me', headers=headers, timeout=15)
        
        if response.status_code == 200:
            data = response.json()
            # Verificar se a resposta contém dados válidos do usuário
            if 'id' in data and 'username' in data:
                return True
        elif response.status_code == 401:
            # Token inválido ou expirado
            return False
        elif response.status_code == 403:
            # Token pode estar válido mas com limitações
            return True
        elif response.status_code == 429:
            # Rate limited - assumir que é válido
            stats.add_log(f"⚠️ Rate limit na validação do token {user_id}")
            return True
        else:
            stats.add_log(f"⚠️ Status desconhecido {response.status_code} para token {user_id}")
            return False
            
    except requests.exceptions.Timeout:
        stats.add_log(f"⚠️ Timeout na validação do token - assumindo válido")
        return True
    except requests.exceptions.ConnectionError:
        stats.add_log(f"⚠️ Erro de conexão na validação - assumindo válido")
        return True
    except Exception as e:
        stats.add_log(f"❌ Erro na validação do token: {str(e)}")
        return False

async def start_dm_system(token):
    """Função para iniciar o sistema de DM com um token específico usando discum"""
    global system_running, tokens_index
    
    try:
        user_id = get_id(token)
        stats.add_log(f"🚀 Iniciando self-bot para: {user_id}")
        
        # Garantir que o token está no índice
        if token not in tokens_index:
            tokens_index[token] = {'is_sleeping': False, 'is_rate_limit': False, 'reply_users_sience': {}}
            stats.add_log(f"📝 Token {user_id} adicionado ao índice")
        
        # Validar token primeiro
        if not validate_token_api(token):
            stats.add_log(f"❌ Token inválido ou expirado: {user_id}")
            return
        
        stats.add_log(f"✅ Token válido confirmado: {user_id}")
        
        # Criar instância do sistema de DM
        nav_settings = settings.copy()
        nav_settings["token"] = token
        nav = instance(db, nav_settings)
        
        def run_self_bot():
            try:
                # Criar cliente discum
                bot = discum.Client(token=token, log=False)
                
                def AfterReadySupp(resp, bot):
                    if resp.event.ready_supplemental:
                        try:
                            guilds = []
                            r = get_token_guilds(token)
                            for g in r:
                                guilds.append(g['id'])
                            bot.gateway.subscribeToGuildEvents(wait=1, guildIDs=guilds, token=token)
                        except:
                            stats.add_log(f"⚠️ Erro ao configurar eventos para {user_id}")
                        
                        stats.add_log(f"✅ Self-bot conectado: {user_id} em {len(bot.getGuilds().json())} servidores")
                        
                        try:
                            bot.gateway.setStatus("idle")
                            bot.gateway.setCustomStatus("Sistema Ativo")
                        except:
                            pass
                
                bot.gateway.command({"function": AfterReadySupp, "params":{"bot":bot}})
                
                @bot.gateway.command
                def handle_event(resp):
                    if not system_running:
                        return
                        
                    if resp.event.message:
                        if settings.get('event_message', True):
                            m = resp.parsed.auto()
                            user = m['author']
                            if "guild_id" in m:
                                user['guild_id'] = m['guild_id']
                            if "channel_id" in m:
                                user['channel_id'] = m['channel_id']
                            if "id" in m:
                                user['message_id'] = m['id']
                            if "content" in m:
                                user['content'] = m['content']
                            if "bot" in m:
                                user['bot'] = m['bot']
                            
                            sience_to_dm(bot, nav, user)
                    
                    elif resp.event.voice_state_updated:
                        if settings.get('event_voice', True):
                            m = resp.parsed.auto()
                            if 'member' in m:
                                user = m['member']['user']
                                if "guild_id" in m:
                                    user['guild_id'] = m['guild_id']
                                if "channel_id" in m:
                                    user['channel_id'] = m['channel_id']
                                if "id" in m:
                                    user['message_id'] = m['id']
                                if "content" in m:
                                    user['content'] = m['content']
                                if "bot" in m:
                                    user['bot'] = m['bot']
                                
                                sience_to_dm(bot, nav, user)
                
                # Executar gateway
                bot.gateway.run(auto_reconnect=True)
                
            except Exception as e:
                stats.add_log(f"❌ Erro no self-bot {user_id}: {str(e)}")
        
        # Executar em thread para não bloquear
        discord_thread = threading.Thread(target=run_self_bot, daemon=True)
        discord_thread.start()
        
        # Aguardar um pouco para verificar se iniciou
        await asyncio.sleep(3)
        stats.add_log(f"🎯 Self-bot {user_id} iniciado com sucesso")
                
    except Exception as e:
        stats.add_log(f"❌ Erro crítico no token {token[:20]}: {str(e)}")

class stats:
    dms_deliver = 0
    dms_captured = 0
    dms_sends = []
    log_messages = []  # Lista para armazenar mensagens de log
    _lock = threading.Lock()
    
    @classmethod
    def add_log(cls, message):
        with cls._lock:
            # Adicionar timestamp à mensagem
            timestamp = time.strftime("%H:%M:%S", time.localtime())
            formatted_message = f"[{timestamp}] {message}"
            cls.log_messages.append(formatted_message)
            # Manter apenas os últimos 100 logs
            if len(cls.log_messages) > 100:
                cls.log_messages.pop(0)
            # Não mostrar logs simples no console
            cls.update_title()
    
    @classmethod
    def update_title(cls):
        """Atualiza o título do console com informações bonitas"""
        try:
            with open('config/tokens.txt', 'r') as f:
                token_count = len([line for line in f.readlines() if line.strip()])
        except:
            token_count = 0
        
        # Contar servidores conectados (aproximação)
        guilds_count = len(client.guilds) if client and hasattr(client, 'guilds') else 0
        
        # Limpar console e mostrar informações bonitas
        print(f'\033[2J\033[H[📤 Enviados {cls.dms_deliver}, 👥 Capturados {cls.dms_captured}, 🔑 Tokens {token_count}, 🏠 Servidores {guilds_count}]')
        
        # Mostrar status do sistema
        status_emoji = "🟢" if system_running else "🔴"
        print(f'[{status_emoji} Sistema: {"Rodando" if system_running else "Parado"} | 📊 Logs: {len(cls.log_messages)} | ⏰ {time.strftime("%H:%M:%S")}]')
        print('━' * 80)

    @classmethod
    def increment_deliver(cls):
        with cls._lock:
            cls.dms_deliver += 1

    @classmethod
    def increment_captured(cls):
        with cls._lock:
            cls.dms_captured += 1

    @classmethod
    def add_dm_send(cls, user_id):
        with cls._lock:
            if user_id not in cls.dms_sends:
                cls.dms_sends.append(user_id)

class instance(object):
    def __init__(self, db, settings) -> None:
        self._ = settings['_']
        self.db = db 
        self.token = settings['token']
        self.settings = settings
        self.message = settings['message']
        self.cookies = False 

    def check_user(self, userid):
        if self.db.store_user_data(self._, self.settings["mongo_cluster_name"], str(userid)):
            return True
        else:
            return False

    def add_user(self, userid):
        if self.db.insert_user_data(self._, self.settings["mongo_cluster_name"], str(userid)):
            return True 
        else:
            return False

def sience_to_dm(bot, nav, user):
    global tokens_index 
    
    # Obter o token do bot
    user_token = bot._Client__user_token
    bot_user_id = get_id(user_token)
    
    # VERIFICAÇÃO CRÍTICA: Ignorar COMPLETAMENTE qualquer ação do próprio self-bot
    if user['id'] == bot_user_id:
        return  # Não processar NADA do próprio bot
    
    # Ignorar bots em geral
    if "bot" in user and user['bot']:
        return
    
    # Verificar se o token existe no índice antes de acessar
    if user_token not in tokens_index:
        stats.add_log(f"⚠️ Token {bot_user_id} não encontrado no índice - adicionando...")
        tokens_index[user_token] = {'is_sleeping': False, 'is_rate_limit': False, 'reply_users_sience': {}}
    
    # VERIFICAR COOLDOWN POR TOKEN - só processa se não estiver em cooldown
    if not tokens_index[user_token]['is_sleeping']:                        
        if "guild_id" in user:
            # Capturar usuários - já garantido que não é o próprio bot pela verificação acima
            if not nav.check_user(user['id']):
                if nav.add_user(user['id']):
                    # ATIVAR COOLDOWN PARA ESTE TOKEN ESPECÍFICO
                    tokens_index[user_token]['is_sleeping'] = True
                    
                    try:
                        newDM = bot.createDM([user['id']]).json()["id"]
                    except:
                        stats.add_log(f"❌ {bot_user_id} - Caiu para verificação")
                        # Resetar cooldown se der erro
                        tokens_index[user_token]['is_sleeping'] = False
                        return bot.gateway.close()
                    
                    r = bot.gateway.request.call(newDM, video=True)
                    bot.typingAction(newDM)
                    stats.increment_captured()
                    
                    try:
                        guild = bot.gateway.session.guild(user["guild_id"]).name
                    except:
                        guild = None
                    
                    stats.add_log(f"✅ {bot_user_id} - Capturado: {user['username']} | Servidor: {guild} | Cooldown: {settings.get('dm_cooldown', 3)}s")
                    
                    # INICIAR THREAD DE COOLDOWN PARA ESTE TOKEN
                    _thread = threading.Thread(target=between_callback, args=(user_token,))
                    _thread.start()
    else:
        # Token em cooldown - não processar
        stats.add_log(f"⏱️ {bot_user_id} - Em cooldown, aguardando...")

    # Processar mensagens DM - já garantido que não é do próprio bot
    if not "guild_id" in user:
        newDM = user['channel_id']
        
        if not user['id'] in stats.dms_sends: 
            stats.dms_sends.append(user['id'])
            if settings['dm_typing']: 
                bot.typingAction(newDM)
            if settings['dm_reaction']: 
                bot.addReaction(newDM, user['message_id'], get_emoji())
            if settings['dm_reply']: 
                bot.reply(newDM, user['message_id'], settings['message'])
            else: 
                bot.sendMessage(newDM, settings['message'])
            if settings['dm_pin']: 
                bot.pinMessage(newDM, user['message_id'])
            
            stats.increment_deliver()
            stats.add_log(f"✅ {bot_user_id} - DM enviada para: {user['username']}")
            tokens_index[user_token]['reply_users_sience'][user['id']] = []

        elif user['id'] in stats.dms_sends:
            # Responder mensagens subsequentes
            bot.addReaction(newDM, user['message_id'], get_emoji())
            for msg in settings.get('reply_messages', []):
                if not user['id'] in tokens_index[user_token]['reply_users_sience']: 
                    tokens_index[user_token]['reply_users_sience'][user['id']] = []
                if not msg in tokens_index[user_token]['reply_users_sience'][user['id']]:
                    bot.typingAction(newDM)
                    time.sleep(random.randint(1, 2))
                    bot.reply(newDM, user['message_id'], msg)
                    tokens_index[user_token]['reply_users_sience'][user['id']].append(msg)
                    break

def between_callback(token):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(reset_sleep_token(token))
    loop.close() 

async def reset_sleep_token(token):
    cooldown_time = settings.get("dm_cooldown", 3)
    if cooldown_time > 0:
        bot_user_id = get_id(token)
        stats.add_log(f"⏱️ {bot_user_id} - Iniciando cooldown de {cooldown_time}s")
        await asyncio.sleep(cooldown_time)
        
        # Verificar se o token ainda existe no índice antes de resetar
        if token in tokens_index:
            tokens_index[token]['is_sleeping'] = False
            stats.add_log(f"✅ {bot_user_id} - Cooldown finalizado, token liberado")
        else:
            stats.add_log(f"⚠️ {bot_user_id} - Token não encontrado no índice ao finalizar cooldown")

def get_token_guilds(token):
    headers = {
        'authorization': token,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
    }
    
    try:
        response = requests.get('https://discord.com/api/v10/users/@me/guilds', headers=headers)
        return response.json()
    except:
        return []

def get_emoji():
    return random.choice(settings.get('reactions', ['👍', '❤️', '😂', '😮', '😢', '😡']))

def send_to_all_servers(message, delay, interaction, bio=None):
    """Enviar mensagem para todos os servidores usando self-bots (tokens de usuário)"""
    try:
        # Ler tokens dos self-bots
        with open('config/tokens.txt', 'r') as f:
            tokens = [token.strip() for token in f.readlines() if token.strip()]
        
        if not tokens:
            stats.add_log("❌ Nenhum self-bot (token) disponível para envio")
            return
        
        stats.add_log(f"📢 Iniciando envio via self-bots para servidores com {len(tokens)} tokens")
        
        total_sent = 0
        total_errors = 0
        servers_reached = set()
        
        for token in tokens:
            try:
                # Validar token básico do self-bot
                user_id = get_id(token)
                stats.add_log(f"🤖 Usando self-bot: {user_id}")
                
                # Criar cliente discum para o self-bot
                bot = discum.Client(token=token, log=False)
                
                # Alterar bio se especificada
                if bio:
                    try:
                        # Usar a API diretamente para alterar a bio
                        headers = {
                            'authorization': token,
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                            'content-type': 'application/json'
                        }
                        
                        bio_url = 'https://discord.com/api/v10/users/@me'
                        bio_payload = {'bio': bio}
                        
                        bio_response = requests.patch(bio_url, headers=headers, json=bio_payload)
                        
                        if bio_response.status_code == 200:
                            stats.add_log(f"📝 Self-bot {user_id} - Bio atualizada: {bio[:30]}{'...' if len(bio) > 30 else ''}")
                        elif bio_response.status_code == 403:
                            stats.add_log(f"⚠️ Self-bot {user_id} - Sem permissão para alterar bio (conta pode não ter acesso à feature)")
                        elif bio_response.status_code == 429:
                            stats.add_log(f"⚠️ Self-bot {user_id} - Rate limited ao alterar bio")
                        else:
                            stats.add_log(f"❌ Self-bot {user_id} - Erro {bio_response.status_code} ao alterar bio")
                        
                        time.sleep(2)  # Delay após alterar bio
                        
                    except Exception as e:
                        stats.add_log(f"❌ Self-bot {user_id} - Erro ao alterar bio: {str(e)}")
                
                # Obter servidores onde o self-bot está presente
                guilds = get_token_guilds(token)
                
                if not guilds:
                    stats.add_log(f"⚠️ Self-bot {user_id} não está em nenhum servidor")
                    continue
                
                stats.add_log(f"🔍 Self-bot {user_id} - {len(guilds)} servidores encontrados")
                
                for guild in guilds:
                    try:
                        guild_id = guild['id']
                        guild_name = guild.get('name', 'Servidor Desconhecido')
                        
                        # Evitar spam - cada servidor recebe mensagem apenas uma vez
                        if guild_id in servers_reached:
                            continue
                        servers_reached.add(guild_id)
                        
                        # Obter canais do servidor usando requests (mais confiável)
                        headers = {
                            'authorization': token,
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                            'content-type': 'application/json'
                        }
                        
                        try:
                            channels_response = requests.get(f'https://discord.com/api/v10/guilds/{guild_id}/channels', headers=headers)
                            if channels_response.status_code != 200:
                                stats.add_log(f"⚠️ Não foi possível obter canais de {guild_name}")
                                continue
                            
                            channels = channels_response.json()
                        except Exception as e:
                            stats.add_log(f"❌ Erro ao obter canais de {guild_name}: {str(e)}")
                            continue
                        
                        # Filtrar apenas canais de texto públicos
                        text_channels = []
                        for channel in channels:
                            if channel.get('type') == 0:  # GUILD_TEXT
                                # Verificar se o canal não é privado/restrito
                                if not channel.get('nsfw', False):
                                    text_channels.append(channel)
                        
                        if not text_channels:
                            stats.add_log(f"⚠️ Nenhum canal de texto encontrado em {guild_name}")
                            continue
                        
                        # Tentar enviar em apenas 1 canal por servidor para evitar spam
                        channel_sent = False
                        
                        # Priorizar canal "geral" ou similar
                        priority_channels = [ch for ch in text_channels if any(word in ch.get('name', '').lower() for word in ['geral', 'general', 'chat', 'principal'])]
                        if priority_channels:
                            channels_to_try = priority_channels[:1]
                        else:
                            channels_to_try = text_channels[:1]
                        
                        for channel in channels_to_try:
                            try:
                                channel_id = channel['id']
                                channel_name = channel.get('name', 'canal')
                                
                                # Simular digitação antes de enviar
                                typing_url = f'https://discord.com/api/v10/channels/{channel_id}/typing'
                                requests.post(typing_url, headers=headers)
                                
                                # Pequeno delay para parecer mais natural
                                time.sleep(random.uniform(1, 3))
                                
                                # Enviar mensagem via self-bot
                                send_url = f'https://discord.com/api/v10/channels/{channel_id}/messages'
                                payload = {'content': message}
                                
                                response = requests.post(send_url, headers=headers, json=payload)
                                
                                if response.status_code == 200:
                                    total_sent += 1
                                    channel_sent = True
                                    stats.add_log(f"✅ Self-bot {user_id} enviou em #{channel_name} ({guild_name})")
                                    break  # Sucesso, próximo servidor
                                elif response.status_code == 403:
                                    stats.add_log(f"⚠️ Self-bot {user_id} sem permissão em #{channel_name} ({guild_name})")
                                    continue
                                elif response.status_code == 429:
                                    stats.add_log(f"⚠️ Self-bot {user_id} rate limited em {guild_name}")
                                    time.sleep(5)  # Rate limit
                                    continue
                                else:
                                    stats.add_log(f"❌ Erro {response.status_code} em #{channel_name} ({guild_name})")
                                    continue
                                    
                            except Exception as e:
                                stats.add_log(f"❌ Erro ao enviar em #{channel_name}: {str(e)}")
                                continue
                            
                            # Delay entre tentativas
                            time.sleep(delay)
                        
                        if not channel_sent:
                            stats.add_log(f"⚠️ Self-bot {user_id} não conseguiu enviar em {guild_name}")
                            total_errors += 1
                            
                    except Exception as e:
                        total_errors += 1
                        stats.add_log(f"❌ Erro no servidor {guild_name}: {str(e)}")
                        continue
                
                # Delay maior entre self-bots para evitar detecção
                time.sleep(random.uniform(3, 7))
                
            except Exception as e:
                stats.add_log(f"❌ Erro crítico com self-bot {token[:20]}: {str(e)}")
                total_errors += 1
                continue
        
        # Relatório final
        stats.add_log(f"📊 Envio concluído:")
        stats.add_log(f"✅ Mensagens enviadas: {total_sent}")
        stats.add_log(f"🏠 Servidores alcançados: {len(servers_reached)}")
        stats.add_log(f"❌ Erros: {total_errors}")
        if bio:
            stats.add_log(f"📝 Bio definida em {len(tokens)} self-bots")
        
        # Atualizar a mensagem de confirmação
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            embed = discord.Embed(
                title="✅ Envio Concluído!",
                description=f"**Resultado do envio:**\n\n"
                           f"📤 **Mensagens enviadas:** {total_sent}\n"
                           f"🏠 **Servidores alcançados:** {len(servers_reached)}\n"
                           f"❌ **Erros:** {total_errors}\n"
                           f"{'📝 **Bio atualizada:** ' + str(len(tokens)) + ' self-bots' if bio else ''}\n\n"
                           f"📋 **Verifique os logs para mais detalhes**",
                color=discord.Color.green()
            )
            
            view = discord.ui.View()
            view.add_item(BackButton())
            
            loop.run_until_complete(
                interaction.edit_original_response(embed=embed, view=view)
            )
            loop.close()
            
        except Exception as e:
            stats.add_log(f"❌ Erro ao atualizar mensagem de confirmação: {str(e)}")
        
    except Exception as e:
        stats.add_log(f"❌ Erro crítico no envio para servidores: {str(e)}")
        
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            embed = discord.Embed(
                title="❌ Erro no Envio",
                description=f"Erro crítico durante o envio:\n```{str(e)}```",
                color=discord.Color.red()
            )
            
            view = discord.ui.View()
            view.add_item(BackButton())
            
            loop.run_until_complete(
                interaction.edit_original_response(embed=embed, view=view)
            )
            loop.close()
            
        except:
            pass

class TokenButton(discord.ui.Button):
    def __init__(self, emoji="🗝️"):
        super().__init__(label="Tokens", style=discord.ButtonStyle.secondary, emoji=emoji)

    async def callback(self, interaction: discord.Interaction):
        with open('config/tokens.txt', 'r') as f:
            tokens = f.read().splitlines()

        embed = discord.Embed(
            title="🔑 Gerenciamento de Tokens",
            description="Gerencie seus tokens abaixo:"
        )

        for i, token in enumerate(tokens, 1):
            masked_token = f"{token[:20]}...{token[-20:]}"
            embed.add_field(name=f"Token {i}", value=f"`{masked_token}`", inline=False)

        buttons = discord.ui.View()
        buttons.add_item(AddTokenButton())
        buttons.add_item(RemoveTokenButton())
        buttons.add_item(ClearTokensButton())
        buttons.add_item(BackButton())

        await interaction.response.edit_message(embed=embed, view=buttons)

class AddTokenButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Adicionar", style=discord.ButtonStyle.success, emoji="✅")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AddTokenModal())

class RemoveTokenButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Remover", style=discord.ButtonStyle.danger, emoji="❌")

    async def callback(self, interaction: discord.Interaction):
        with open('config/tokens.txt', 'r') as f:
            tokens = [token.strip() for token in f.readlines() if token.strip()]
        
        if not tokens:
            embed = discord.Embed(
                title="❌ Nenhum Token",
                description="Não há tokens para remover!"
            )
            buttons = discord.ui.View()
            buttons.add_item(BackButton())
            await interaction.response.edit_message(embed=embed, view=buttons)
            return
        
        embed = discord.Embed(
            title="🗑️ Remover Tokens",
            description="Selecione os tokens que deseja remover:"
        )
        
        view = TokenRemovalView(tokens)
        await interaction.response.edit_message(embed=embed, view=view)

class ClearTokensButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Limpar", style=discord.ButtonStyle.danger, emoji="🧹")

    async def callback(self, interaction: discord.Interaction):
        with open('config/tokens.txt', 'w') as f:
            f.write("")
        
        embed = discord.Embed(
            title="✅ Sucesso",
            description="Tokens limpos com sucesso!"
        )
        
        buttons = discord.ui.View()
        buttons.add_item(BackButton())
        
        await interaction.response.edit_message(embed=embed, view=buttons)

class ServerMessageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Mensagem Server", style=discord.ButtonStyle.secondary, emoji="📢")

    async def callback(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📢 Mensagem para Servidores",
            description="**Envie uma mensagem para todos os servidores**\n\n"
                       "🎯 **Como funciona:**\n"
                       "• O bot enviará a mensagem em todos os canais onde tem permissão\n"
                       "• Funciona apenas em servidores onde o bot está presente\n"
                       "• Respeitará as permissões de cada canal\n\n"
                       "⚠️ **Atenção:** Use com responsabilidade!",
            color=discord.Color.orange()
        )
        
        buttons = discord.ui.View()
        buttons.add_item(SendServerMessageButton())
        buttons.add_item(BackButton())
        
        await interaction.response.edit_message(embed=embed, view=buttons)

class SendServerMessageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Enviar Mensagem", style=discord.ButtonStyle.primary, emoji="📤")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(ServerMessageModal())

class ServerMessageModal(discord.ui.Modal, title='📢 Enviar Mensagem para Servidores'):
    def __init__(self):
        super().__init__()
        
        self.message_content = discord.ui.TextInput(
            label='Mensagem',
            style=discord.TextStyle.paragraph,
            placeholder='Digite a mensagem que será enviada para todos os servidores...',
            required=True,
            max_length=2000
        )
        self.add_item(self.message_content)
        
        self.bio_content = discord.ui.TextInput(
            label='Bio dos Self-bots (Opcional)',
            style=discord.TextStyle.paragraph,
            placeholder='Digite a bio que será definida nos self-bots (deixe vazio para não alterar)',
            required=False,
            max_length=190
        )
        self.add_item(self.bio_content)
        
        self.delay_seconds = discord.ui.TextInput(
            label='Delay entre envios (segundos)',
            placeholder='Tempo de espera entre cada canal (recomendado: 2-5)',
            default='3',
            required=True,
            max_length=3
        )
        self.add_item(self.delay_seconds)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            delay = int(self.delay_seconds.value)
            if delay < 1:
                delay = 1
            elif delay > 60:
                delay = 60
        except ValueError:
            delay = 3
        
        message = self.message_content.value
        bio = self.bio_content.value.strip() if self.bio_content.value else None
        
        # Confirmar envio
        embed = discord.Embed(
            title="⚠️ Confirmar Envio",
            description=f"**Você está prestes a enviar esta mensagem para TODOS os servidores:**\n\n"
                       f"```\n{message}\n```\n\n"
                       f"**Delay:** {delay} segundos entre envios\n"
                       f"**Bio:** {'`' + bio + '`' if bio else 'Não será alterada'}\n"
                       f"**Esta ação não pode ser desfeita!**",
            color=discord.Color.red()
        )
        
        view = ConfirmServerMessageView(message, delay, bio)
        await interaction.response.edit_message(embed=embed, view=view)

class ConfirmServerMessageView(discord.ui.View):
    def __init__(self, message, delay, bio=None):
        super().__init__()
        self.message = message
        self.delay = delay
        self.bio = bio
    
    @discord.ui.button(label="✅ CONFIRMAR ENVIO", style=discord.ButtonStyle.danger)
    async def confirm_send(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Iniciar o processo de envio
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="📤 Enviando Mensagens...",
                description="Iniciando envio para todos os servidores. Aguarde...",
                color=discord.Color.yellow()
            ),
            view=discord.ui.View()
        )
        
        # Executar em thread para não bloquear
        thread = threading.Thread(target=send_to_all_servers, args=(self.message, self.delay, interaction, self.bio))
        thread.start()
    
    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel_send(self, interaction: discord.Interaction, button: discord.ui.Button):
        server_button = ServerMessageButton()
        await server_button.callback(interaction)

class MessageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Mensagem", style=discord.ButtonStyle.secondary, emoji="💬")

    async def callback(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📝 Gerenciamento de Mensagem",
            description="Gerencie a mensagem do bot abaixo:"
        )
        await interaction.response.edit_message(embed=embed, view=MessagePanel())

class SettingsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Configurações", style=discord.ButtonStyle.secondary, emoji="🔧")

    async def callback(self, interaction: discord.Interaction):
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)
        
        embed = discord.Embed(
            title="⚙️ Configurações Avançadas do Sistema",
            description="**Gerencie todas as configurações do bot de forma intuitiva**\n\n"
                       "🎯 **Use os botões abaixo para:**\n"
                       "• Visualizar configurações atuais\n"
                       "• Ativar/desativar funcionalidades\n"
                       "• Ajustar parâmetros do sistema\n"
                       "• Personalizar comportamentos",
            color=discord.Color.orange()
        )
        
        # Adicionar campo com configurações atuais
        config_status = f"""
**🔧 Status Atual das Configurações:**
```yaml
Auto Reply: {'✅ Ativado' if settings.get('dm_reply', False) else '❌ Desativado'}
Digitando: {'✅ Ativado' if settings.get('dm_typing', False) else '❌ Desativado'}  
Reações: {'✅ Ativado' if settings.get('dm_reaction', False) else '❌ Desativado'}
Fixar Msg: {'✅ Ativado' if settings.get('dm_pin', False) else '❌ Desativado'}
Cooldown: {settings.get('dm_cooldown', 3)} segundos
```"""
        
        embed.add_field(
            name="📊 Resumo das Configurações",
            value=config_status,
            inline=False
        )
        
        embed.set_footer(text="💡 Dica: Use os menus para navegar entre as diferentes categorias de configurações")
        
        await interaction.response.edit_message(embed=embed, view=AdvancedSettingsPanel())

class ToggleButton(discord.ui.Button):
    def __init__(self, feature_name, setting_key, is_active):
        self.feature_name = feature_name
        self.setting_key = setting_key
        self.is_active = is_active
        super().__init__(
            label=f"{feature_name}: {'Ativado' if is_active else 'Desativado'}", 
            style=discord.ButtonStyle.green if is_active else discord.ButtonStyle.danger,
            custom_id=f"toggle_{setting_key}"
        )

    async def callback(self, interaction: discord.Interaction):
        # Inverter o estado
        self.is_active = not self.is_active

        # Atualizar o botão
        self.label = f"{self.feature_name}: {'Ativado' if self.is_active else 'Desativado'}"
        self.style = discord.ButtonStyle.green if self.is_active else discord.ButtonStyle.danger

        # Atualizar a configuração no YAML
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)

        settings[self.setting_key] = self.is_active

        with open('config/settings.yaml', 'w') as f:
            yaml.dump(settings, f)

        # Atualizar a visualização
        await interaction.response.edit_message(view=self.view)

        # Notificar usuário
        await interaction.followup.send(f"Configuração '{self.feature_name}' foi {'ativada' if self.is_active else 'desativada'}.", ephemeral=True)

class StopButton(discord.ui.Button):
    def __init__(self, emoji="🛑"):
        super().__init__(label="Parar", style=discord.ButtonStyle.danger, emoji=emoji)

    async def callback(self, interaction: discord.Interaction):
        global system_running, dm_tasks
        
        try:
            if not system_running:
                embed = discord.Embed(
                    title="⚠️ Sistema já está parado",
                    description="O sistema não está em execução!"
                )
                buttons = discord.ui.View()
                buttons.add_item(StartButton())
                buttons.add_item(BackButton())
                await interaction.response.edit_message(embed=embed, view=buttons)
                return
            
            # Parar todas as tarefas
            system_running = False
            for task in dm_tasks:
                if not task.done():
                    task.cancel()
            dm_tasks.clear()
            
            # Parar processos Python do sistema principal
            import subprocess
            import sys
            try:
                if sys.platform == "win32":
                    subprocess.run(["taskkill", "/f", "/im", "python.exe"], capture_output=True)
                else:
                    subprocess.run(["pkill", "-f", "main.py"], capture_output=True)
            except:
                pass
            
            stats.add_log("🛑 Sistema parado pelo usuário")
            
            embed = discord.Embed(
                title="⏹️ Sistema Parado",
                description="O sistema foi parado com sucesso!"
            )
            
            buttons = discord.ui.View()
            buttons.add_item(StartButton())
            buttons.add_item(BackButton())
            
            await interaction.response.edit_message(embed=embed, view=buttons)
            
        except Exception as e:
            stats.add_log(f"Erro ao parar sistema: {str(e)}")
            embed = discord.Embed(
                title="❌ Erro ao Parar",
                description=f"Erro: {str(e)}"
            )
            buttons = discord.ui.View()
            buttons.add_item(BackButton())
            
            if not interaction.response.is_done():
                await interaction.response.edit_message(embed=embed, view=buttons)
            else:
                await interaction.edit_original_response(embed=embed, view=buttons)

class ViewLogsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Logs", style=discord.ButtonStyle.secondary, emoji="📊")

    async def callback(self, interaction: discord.Interaction):
        # Mostrar estatísticas bonitas em vez de logs simples
        try:
            with open('config/tokens.txt', 'r') as f:
                token_count = len([line for line in f.readlines() if line.strip()])
        except:
            token_count = 0
        
        guilds_count = len(client.guilds) if client and hasattr(client, 'guilds') else 0
        
        embed = discord.Embed(
            title="📊 Estatísticas do Sistema",
            description="**Status em Tempo Real**",
            color=discord.Color.green() if system_running else discord.Color.red()
        )
        
        embed.add_field(
            name="📈 Contadores Principais",
            value=f"```\n📤 DMs Enviadas: {stats.dms_deliver}\n👥 Usuários Capturados: {stats.dms_captured}\n🔑 Tokens Ativos: {token_count}\n🏠 Servidores Conectados: {guilds_count}\n```",
            inline=False
        )
        
        embed.add_field(
            name="🔥 Sistema",
            value=f"```\n{'🟢 Online' if system_running else '🔴 Offline'}\n⏰ {time.strftime('%H:%M:%S')}\n📋 Logs: {len(stats.log_messages)}\n```",
            inline=False
        )
        
        # Mostrar últimos logs importantes
        important_logs = [log for log in stats.log_messages[-10:] if any(word in log for word in ['iniciado', 'parado', 'erro', 'conectado'])]
        if important_logs:
            embed.add_field(
                name="📋 Últimas Atividades",
                value=f"```\n{chr(10).join(important_logs[-5:])}\n```",
                inline=False
            )
        
        view = discord.ui.View()
        view.add_item(RefreshLogsButton())
        view.add_item(BackButton())
        
        await interaction.response.edit_message(embed=embed, view=view)

class RefreshLogsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Atualizar", style=discord.ButtonStyle.primary, emoji="🔃")
    
    async def callback(self, interaction: discord.Interaction):
        # Usar a mesma lógica do ViewLogsButton
        logs_button = ViewLogsButton()
        await logs_button.callback(interaction)

class ModernPainelView(discord.ui.View):
    def __init__(self, is_owner_user=False):
        super().__init__(timeout=None)
        self.is_owner_user = is_owner_user
        
        # Adicionar botão de iniciar sistema
        self.add_item(ModernStartButton())
        
        # Adicionar menu de seleção principal
        options = [
            discord.SelectOption(label="Gerenciar Tokens", description="Adicionar, remover ou visualizar tokens", value="tokens"),
            discord.SelectOption(label="Gerenciar Mensagem", description="Editar a mensagem do bot", value="message"),
            discord.SelectOption(label="Mensagem Server", description="Enviar mensagem em todos os servidores", value="server_message"),
            discord.SelectOption(label="Configurações", description="Alterar configurações do sistema", value="settings"),
            discord.SelectOption(label="Ver Logs", description="Visualizar logs do sistema", value="logs"),
        ]
        
        # Adicionar opção de permissões apenas para donos
        if self.is_owner_user:
            options.append(discord.SelectOption(label="Gerenciar Permissões", description="Gerenciar usuários permitidos", value="permissions"))
        
        self.add_item(ModernPainelDropdown(options))

class ModernPainelDropdown(discord.ui.Select):
    def __init__(self, options):
        super().__init__(placeholder="Selecione uma ação...", options=options)
    
    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "tokens":
            token_button = TokenButton()
            await token_button.callback(interaction)
        elif self.values[0] == "message":
            message_button = MessageButton()
            await message_button.callback(interaction)
        elif self.values[0] == "server_message":
            server_message_button = ServerMessageButton()
            await server_message_button.callback(interaction)
        elif self.values[0] == "settings":
            settings_button = SettingsButton()
            await settings_button.callback(interaction)
        elif self.values[0] == "logs":
            logs_button = ViewLogsButton()
            await logs_button.callback(interaction)
        elif self.values[0] == "permissions":
            perm_button = PermissionButton()
            await perm_button.callback(interaction)

class ModernStartButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Iniciar Sistema", style=discord.ButtonStyle.success)

    async def callback(self, interaction: discord.Interaction):
        start_button = StartButton()
        await start_button.callback(interaction)

class PainelDropdown(discord.ui.Select):
    def __init__(self, options):
        super().__init__(placeholder="📋 Selecione uma opção...", options=options)
    
    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "tokens":
            token_button = TokenButton()
            await token_button.callback(interaction)
        elif self.values[0] == "message":
            message_button = MessageButton()
            await message_button.callback(interaction)
        elif self.values[0] == "server_message":
            server_message_button = ServerMessageButton()
            await server_message_button.callback(interaction)
        elif self.values[0] == "settings":
            settings_button = SettingsButton()
            await settings_button.callback(interaction)
        elif self.values[0] == "logs":
            logs_button = ViewLogsButton()
            await logs_button.callback(interaction)
        elif self.values[0] == "permissions":
            perm_button = PermissionButton()
            await perm_button.callback(interaction)

class PainelView(discord.ui.View):
    def __init__(self, is_owner_user=False):
        super().__init__(timeout=None)
        self.is_owner_user = is_owner_user
        
        # Adicionar botões principais
        self.add_item(TokenButton())
        self.add_item(MessageButton())
        self.add_item(SettingsButton())
        self.add_item(ViewLogsButton())
        
        # Adicionar botões de controle
        self.add_item(StartButton())
        self.add_item(StopButton())
        
        # Adicionar botão de permissões apenas para donos
        if self.is_owner_user:
            self.add_item(PermissionButton())

class BackButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Voltar", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        # Retornar para o painel original do comando /painel
        with open('config/tokens.txt', 'r') as f:
            token_count = len(f.readlines())

        # Obter informações do sistema
        ping = round(client.latency * 1000)
        status_color = "Online" if ping < 200 else "Instável" if ping < 500 else "Alto Delay"
        
        # Embed moderno sem emojis (mesmo do comando /painel)
        embed = discord.Embed(
            title="Painel de Controle do Bot",
            description=f"Gerencie o sistema de controle {interaction.user.mention}",
            color=discord.Color.blue()
        )
        
        # Adicionar informações do sistema
        embed.add_field(
            name="Status do Sistema",
            value=f"**Status**: {status_color}\n**Ping**: {ping}ms\n**Tokens**: {token_count}",
            inline=True
        )
        
        embed.add_field(
            name="Estatísticas",
            value=f"**DMs Enviadas**: {stats.dms_deliver}\n**Usuários**: {stats.dms_captured}\n**Logs**: {len(stats.log_messages)}",
            inline=True
        )
        
        embed.add_field(
            name="Sistema Ativo",
            value=f"**Status**: {'Rodando' if system_running else 'Parado'}\n**Uptime**: Ativo\n**Memoria**: Normal",
            inline=True
        )
        
        if interaction.user.avatar:
            embed.set_thumbnail(url=interaction.user.avatar.url)
        
        embed.set_footer(text="Sistema de Controle - Desenvolvido pela Equipe")

        # Usar o sistema de view moderno (mesmo do comando /painel)
        view = ModernPainelView(is_owner(interaction.user.id))
        await interaction.response.edit_message(embed=embed, view=view)

class PermissionButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Permissões", style=discord.ButtonStyle.secondary, emoji="🔐")

    async def callback(self, interaction: discord.Interaction):
        if not is_owner(interaction.user.id):
            embed = discord.Embed(
                title="❌ Acesso Negado",
                description="Você não tem permissão para gerenciar permissões."
            )
            buttons = discord.ui.View()
            buttons.add_item(BackButton())
            await interaction.response.edit_message(embed=embed, view=buttons)
            return
        
        # Mostrar painel de permissões
        embed = discord.Embed(
            title="🔒 Gerenciamento de Permissões",
            description="Gerencie quem pode acessar o painel de controle."
        )
        
        # Listar usuários permitidos
        try:
            with open('data/perm.json', 'r') as f:
                perm = json.load(f)
            
            owners = perm.get('owners', [])
            permitted = perm.get('permitted', [])
            
            if owners:
                embed.add_field(name="👑 Donos adicionais", value="\n".join([f"<@{owner}> ({owner})" for owner in owners]), inline=False)
            else:
                embed.add_field(name="👑 Donos adicionais", value="Nenhum", inline=False)
                
            if permitted:
                embed.add_field(name="🔑 Usuários permitidos", value="\n".join([f"<@{user}> ({user})" for user in permitted]), inline=False)
            else:
                embed.add_field(name="🔑 Usuários permitidos", value="Nenhum", inline=False)
        except:
            embed.add_field(name="Erro", value="Não foi possível carregar as permissões.", inline=False)
        
        buttons = PermissionPanel()
        await interaction.response.edit_message(embed=embed, view=buttons)

class PermissionPanel(discord.ui.View):
    def __init__(self):
        super().__init__()
    
    @discord.ui.button(label="Adicionar", style=discord.ButtonStyle.success, emoji="➕")
    async def add_permission(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(AddPermissionModal())
    
    @discord.ui.button(label="Remover", style=discord.ButtonStyle.danger, emoji="➖")
    async def remove_permission(self, interaction: discord.Interaction, button: discord.ui.Button):
        with open('data/perm.json', 'r') as f:
            perm = json.load(f)
        
        owners = perm.get('owners', [])
        permitted = perm.get('permitted', [])
        
        if not owners and not permitted:
            embed = discord.Embed(
                title="❌ Erro",
                description="Não há usuários com permissão para remover."
            )
            buttons = discord.ui.View()
            buttons.add_item(BackButton())
            await interaction.response.edit_message(embed=embed, view=buttons)
            return
        
        await interaction.response.send_modal(RemovePermissionModal())

    @discord.ui.button(label="Voltar", style=discord.ButtonStyle.secondary, emoji="◀️")
    async def back_to_main(self, interaction: discord.Interaction, button: discord.ui.Button):
        back_btn = BackButton()
        await back_btn.callback(interaction)

class AddPermissionModal(discord.ui.Modal, title='Adicionar Permissão'):
    user_id = discord.ui.TextInput(label='ID do Usuário', placeholder='Digite o ID do usuário')
    permission_type = discord.ui.TextInput(
        label='Tipo de Permissão', 
        placeholder='Digite "owner" para dono ou "user" para usuário comum',
        default="user"
    )

    async def on_submit(self, interaction: discord.Interaction):
        user_id = self.user_id.value.strip()
        perm_type = self.permission_type.value.strip().lower()
        
        if not user_id.isdigit():
            await interaction.response.send_message("ID inválido. O ID deve conter apenas números.", ephemeral=True)
            return
        
        if perm_type not in ["owner", "user"]:
            await interaction.response.send_message('Tipo de permissão inválido. Use "owner" ou "user".', ephemeral=True)
            return
        
        try:
            with open('data/perm.json', 'r') as f:
                perm = json.load(f)
            
            if perm_type == "owner":
                if user_id not in perm.get('owners', []):
                    perm.setdefault('owners', []).append(user_id)
            else:
                if user_id not in perm.get('permitted', []):
                    perm.setdefault('permitted', []).append(user_id)
            
            with open('data/perm.json', 'w') as f:
                json.dump(perm, f, indent=2)
            
            await interaction.response.send_message(f"Permissão adicionada com sucesso para o ID {user_id}!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Erro ao adicionar permissão: {str(e)}", ephemeral=True)

class RemovePermissionModal(discord.ui.Modal, title='Remover Permissão'):
    user_id = discord.ui.TextInput(label='ID do Usuário', placeholder='Digite o ID do usuário a ser removido')

    async def on_submit(self, interaction: discord.Interaction):
        user_id = self.user_id.value.strip()
        
        if not user_id.isdigit():
            await interaction.response.send_message("ID inválido. O ID deve conter apenas números.", ephemeral=True)
            return
        
        try:
            with open('data/perm.json', 'r') as f:
                perm = json.load(f)
            
            if user_id in perm.get('owners', []):
                perm['owners'].remove(user_id)
                removed = True
            elif user_id in perm.get('permitted', []):
                perm['permitted'].remove(user_id)
                removed = True
            else:
                removed = False
            
            if removed:
                with open('data/perm.json', 'w') as f:
                    json.dump(perm, f, indent=2)
                await interaction.response.send_message(f"Permissão removida com sucesso para o ID {user_id}!", ephemeral=True)
            else:
                await interaction.response.send_message(f"O ID {user_id} não possui permissões para serem removidas.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Erro ao remover permissão: {str(e)}", ephemeral=True)

class AddTokenModal(discord.ui.Modal, title='Adicionar Token'):
    token = discord.ui.TextInput(label='Token', placeholder='Cole o token aqui')

    async def on_submit(self, interaction: discord.Interaction):
        token = self.token.value
        with open('config/tokens.txt', 'a') as f:
            f.write(f"{token}\n")
        await interaction.response.send_message(f"Token adicionado com sucesso!", ephemeral=True)

class TokenRemovalView(discord.ui.View):
    def __init__(self, tokens):
        super().__init__()
        self.tokens = tokens
        
        # Criar menu de seleção múltipla
        options = []
        for i, token in enumerate(tokens):
            masked_token = f"{token[:15]}...{token[-15:]}"
            user_id = get_id(token)
            options.append(discord.SelectOption(
                label=f"Token {i+1}",
                description=f"ID: {user_id} | {masked_token}",
                value=str(i)
            ))
        
        if len(options) <= 25:  # Limite do Discord
            self.add_item(TokenSelectionDropdown(tokens, options))
        else:
            # Se houver muitos tokens, dividir em páginas
            for page in range(0, len(options), 25):
                page_options = options[page:page+25]
                self.add_item(TokenSelectionDropdown(tokens, page_options, page // 25))
        
        # Botões de ação
        self.add_item(RemoveAllTokensButton())
        self.add_item(BackToTokensButton())

class TokenSelectionDropdown(discord.ui.Select):
    def __init__(self, tokens, options, page=0):
        self.tokens = tokens
        self.page = page
        placeholder = f"Selecione tokens para remover (Página {page+1})" if page > 0 else "Selecione tokens para remover"
        super().__init__(placeholder=placeholder, options=options, max_values=min(len(options), 25))
    
    async def callback(self, interaction: discord.Interaction):
        selected_indices = [int(value) for value in self.values]
        tokens_to_remove = [self.tokens[i] for i in selected_indices]
        
        # Confirmar remoção
        embed = discord.Embed(
            title="⚠️ Confirmar Remoção",
            description=f"Você está prestes a remover **{len(tokens_to_remove)}** tokens:"
        )
        
        for i, token in enumerate(tokens_to_remove):
            user_id = get_id(token)
            masked = f"{token[:15]}...{token[-15:]}"
            embed.add_field(
                name=f"Token {i+1}",
                value=f"ID: `{user_id}`\nToken: `{masked}`",
                inline=True
            )
        
        view = ConfirmRemovalView(tokens_to_remove)
        await interaction.response.edit_message(embed=embed, view=view)

class ConfirmRemovalView(discord.ui.View):
    def __init__(self, tokens_to_remove):
        super().__init__()
        self.tokens_to_remove = tokens_to_remove
    
    @discord.ui.button(label="✅ Confirmar Remoção", style=discord.ButtonStyle.danger)
    async def confirm_removal(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            with open('config/tokens.txt', 'r') as f:
                all_tokens = [token.strip() for token in f.readlines() if token.strip()]
            
            # Remover tokens selecionados
            remaining_tokens = [token for token in all_tokens if token not in self.tokens_to_remove]
            
            with open('config/tokens.txt', 'w') as f:
                for token in remaining_tokens:
                    f.write(f"{token}\n")
            
            embed = discord.Embed(
                title="✅ Tokens Removidos",
                description=f"**{len(self.tokens_to_remove)}** tokens foram removidos com sucesso!\n\n"
                           f"**Tokens restantes:** {len(remaining_tokens)}",
                color=discord.Color.green()
            )
            
            buttons = discord.ui.View()
            buttons.add_item(BackToTokensButton())
            
            await interaction.response.edit_message(embed=embed, view=buttons)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Erro",
                description=f"Erro ao remover tokens: {str(e)}"
            )
            buttons = discord.ui.View()
            buttons.add_item(BackToTokensButton())
            await interaction.response.edit_message(embed=embed, view=buttons)
    
    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel_removal(self, interaction: discord.Interaction, button: discord.ui.Button):
        token_button = TokenButton()
        await token_button.callback(interaction)

class RemoveAllTokensButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🗑️ Remover Todos", style=discord.ButtonStyle.danger)
    
    async def callback(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="⚠️ ATENÇÃO - Remover Todos os Tokens",
            description="**Você está prestes a remover TODOS os tokens!**\n\n"
                       "⚠️ Esta ação é **irreversível**\n"
                       "🚨 O sistema ficará sem tokens para funcionar\n\n"
                       "Tem certeza que deseja continuar?",
            color=discord.Color.red()
        )
        
        view = ConfirmRemoveAllView()
        await interaction.response.edit_message(embed=embed, view=view)

class ConfirmRemoveAllView(discord.ui.View):
    def __init__(self):
        super().__init__()
    
    @discord.ui.button(label="🗑️ SIM, REMOVER TODOS", style=discord.ButtonStyle.danger)
    async def confirm_remove_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        with open('config/tokens.txt', 'w') as f:
            f.write("")
        
        embed = discord.Embed(
            title="✅ Todos os Tokens Removidos",
            description="Todos os tokens foram removidos com sucesso!\n\n"
                       "⚠️ **Sistema sem tokens** - adicione novos tokens para usar o sistema",
            color=discord.Color.green()
        )
        
        buttons = discord.ui.View()
        buttons.add_item(AddTokenButton())
        buttons.add_item(BackToTokensButton())
        await interaction.response.edit_message(embed=embed, view=buttons)
    
    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel_remove_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        token_button = TokenButton()
        await token_button.callback(interaction)

class BackToTokensButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="↩️ Voltar aos Tokens", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        token_button = TokenButton()
        await token_button.callback(interaction)

class MessageModal(discord.ui.Modal, title="Gerenciar Mensagem"):
    def __init__(self, current_message=""):
        super().__init__()
        self.message = discord.ui.TextInput(
            label="Mensagem",
            style=discord.TextStyle.paragraph,
            placeholder="Digite a mensagem aqui...",
            default=current_message,
            required=True
        )
        self.add_item(self.message)

    async def on_submit(self, interaction: discord.Interaction):
        with open('config/message.txt', 'w', encoding='utf-8') as f:
            f.write(self.message.value)
        await interaction.response.send_message("✅ Mensagem atualizada com sucesso!", ephemeral=True)

class MessagePanel(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.load_current_message()

    def load_current_message(self):
        try:
            with open('config/message.txt', 'r', encoding='utf-8') as f:
                self.current_message = f.read()
        except:
            self.current_message = "Nenhuma mensagem definida"

    @discord.ui.button(label="Ver Atual", style=discord.ButtonStyle.secondary, emoji="👀")
    async def view_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="📝 Mensagem Atual",
            description=self.current_message
        )
        view = discord.ui.View()
        view.add_item(BackButton())
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Editar", style=discord.ButtonStyle.primary, emoji="📝")
    async def edit_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = MessageModal(self.current_message)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Nova", style=discord.ButtonStyle.success, emoji="📄")
    async def new_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = MessageModal()
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Deletar", style=discord.ButtonStyle.danger, emoji="🗂️")
    async def delete_message(self, interaction: discord.Interaction, button: discord.ui.Button):
        with open('config/message.txt', 'w', encoding='utf-8') as f:
            f.write("")
        self.current_message = ""
        
        embed = discord.Embed(
            title="✅ Sucesso",
            description="Mensagem deletada com sucesso!"
        )
        
        buttons = discord.ui.View()
        buttons.add_item(BackButton())
        
        await interaction.response.edit_message(embed=embed, view=buttons)

    @discord.ui.button(label="Voltar", style=discord.ButtonStyle.secondary, emoji="◀️", row=1)
    async def back_to_main(self, interaction: discord.Interaction, button: discord.ui.Button):
        back_btn = BackButton()
        await back_btn.callback(interaction)

class DMBehaviorPanel(discord.ui.View):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        
        # Adicionar toggles para configurações de DM
        self.add_item(ToggleButton("Auto Reply", "dm_reply", settings.get('dm_reply', False)))
        self.add_item(ToggleButton("Digitando", "dm_typing", settings.get('dm_typing', False)))
        self.add_item(ToggleButton("Reações", "dm_reaction", settings.get('dm_reaction', False)))
        self.add_item(ToggleButton("Fixar Mensagem", "dm_pin", settings.get('dm_pin', False)))
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️", row=2)
    async def back_to_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)

class PerformancePanel(discord.ui.View):
    def __init__(self):
        super().__init__()
    
    @discord.ui.button(label="⏱️ Ajustar Cooldown", style=discord.ButtonStyle.primary, emoji="⏱️")
    async def adjust_cooldown(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = CooldownModal()
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🚀 Modo Rápido", style=discord.ButtonStyle.success, emoji="🚀")
    async def fast_mode(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.set_cooldown(interaction, 1, "Modo Rápido")
    
    @discord.ui.button(label="⚖️ Modo Balanceado", style=discord.ButtonStyle.primary, emoji="⚖️")
    async def balanced_mode(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.set_cooldown(interaction, 3, "Modo Balanceado")
    
    @discord.ui.button(label="🛡️ Modo Seguro", style=discord.ButtonStyle.secondary, emoji="🛡️")
    async def safe_mode(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.set_cooldown(interaction, 5, "Modo Seguro")
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️", row=2)
    async def back_to_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)
    
    async def set_cooldown(self, interaction, cooldown_value, mode_name):
        try:
            with open('config/settings.yaml', 'r') as f:
                settings = yaml.safe_load(f)
            
            settings['dm_cooldown'] = cooldown_value
            
            with open('config/settings.yaml', 'w') as f:
                yaml.dump(settings, f)
            
            await interaction.response.send_message(f"✅ {mode_name} ativado! Cooldown definido para {cooldown_value} segundos.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao alterar configuração: {str(e)}", ephemeral=True)

class EventsPanel(discord.ui.View):
    def __init__(self, settings):
        super().__init__()
        self.add_item(ToggleButton("Evento de Mensagem", "event_message", settings.get('event_message', True)))
        self.add_item(ToggleButton("Evento de Voz", "event_voice", settings.get('event_voice', True)))
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️", row=1)
    async def back_to_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)

class SecurityPanel(discord.ui.View):
    def __init__(self):
        super().__init__()
    
    @discord.ui.button(label="🔒 Configurações em breve", style=discord.ButtonStyle.secondary, emoji="🔒", disabled=True)
    async def security_placeholder(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️")
    async def back_to_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)

class AllSettingsPanel(discord.ui.View):
    def __init__(self):
        super().__init__()
    
    @discord.ui.button(label="✏️ Editar YAML", style=discord.ButtonStyle.primary, emoji="✏️")
    async def edit_yaml(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = AdvancedSettingsModal()
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🔄 Recarregar", style=discord.ButtonStyle.secondary, emoji="🔄")
    async def reload_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        dropdown = SettingsDropdown([])
        await dropdown.show_all_settings(interaction)
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️")
    async def back_to_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)

class CooldownModal(discord.ui.Modal, title='⏱️ Ajustar Cooldown'):
    def __init__(self):
        super().__init__()
        with open('config/settings.yaml', 'r') as f:
            current_settings = yaml.safe_load(f)
        
        self.cooldown = discord.ui.TextInput(
            label='Cooldown (segundos)',
            placeholder='Tempo entre DMs (recomendado: 3-5 segundos)',
            default=str(current_settings.get('dm_cooldown', 3)),
            required=True
        )
        self.add_item(self.cooldown)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            cooldown_value = int(self.cooldown.value)
            
            if cooldown_value < 1:
                await interaction.response.send_message("❌ Cooldown deve ser maior que 0 segundos!", ephemeral=True)
                return
            
            with open('config/settings.yaml', 'r') as f:
                settings = yaml.safe_load(f)

            settings['dm_cooldown'] = cooldown_value

            with open('config/settings.yaml', 'w') as f:
                yaml.dump(settings, f)

            status = "🟢 Seguro" if cooldown_value >= 5 else "🟡 Balanceado" if cooldown_value >= 3 else "🔴 Rápido"
            await interaction.response.send_message(f"✅ Cooldown atualizado para {cooldown_value} segundos! Status: {status}", ephemeral=True)

        except ValueError:
            await interaction.response.send_message("❌ Por favor, insira um número válido!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao atualizar configurações: {str(e)}", ephemeral=True)

class AdvancedSettingsModal(discord.ui.Modal, title='✏️ Editor Avançado de Configurações'):
    def __init__(self):
        super().__init__()
        
        with open('config/settings.yaml', 'r') as f:
            current_content = f.read()
        
        self.settings_content = discord.ui.TextInput(
            label='Configurações YAML',
            style=discord.TextStyle.paragraph,
            placeholder='Edite as configurações em formato YAML...',
            default=current_content,
            required=True
        )
        self.add_item(self.settings_content)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            # Validar YAML
            yaml.safe_load(self.settings_content.value)
            
            # Salvar configurações
            with open('config/settings.yaml', 'w') as f:
                f.write(self.settings_content.value)
            
            await interaction.response.send_message("✅ Configurações atualizadas com sucesso!", ephemeral=True)
            
        except yaml.YAMLError as e:
            await interaction.response.send_message(f"❌ Erro no formato YAML: {str(e)}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao salvar configurações: {str(e)}", ephemeral=True)

class AdvancedSettingsPanel(discord.ui.View):
    def __init__(self):
        super().__init__()
        
        # Menu de seleção para categorias
        options = [
            discord.SelectOption(
                label="🤖 Comportamento DM", 
                description="Auto reply, digitando, reações automáticas", 
                value="dm_behavior", 
                emoji="🤖"
            ),
            discord.SelectOption(
                label="⚡ Performance", 
                description="Cooldown, rate limiting, otimizações", 
                value="performance", 
                emoji="⚡"
            ),
            discord.SelectOption(
                label="🎯 Eventos", 
                description="Eventos de mensagem, voz e notificações", 
                value="events", 
                emoji="🎯"
            ),
            discord.SelectOption(
                label="🛡️ Segurança", 
                description="Configurações de segurança e proteção", 
                value="security", 
                emoji="🛡️"
            ),
            discord.SelectOption(
                label="📈 Ver Todas", 
                description="Visualizar todas as configurações atuais", 
                value="view_all", 
                emoji="📈"
            )
        ]
        
        self.add_item(SettingsDropdown(options))
    
    @discord.ui.button(label="🔄 Atualizar", style=discord.ButtonStyle.primary, emoji="🔄")
    async def refresh_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings_button = SettingsButton()
        await settings_button.callback(interaction)
    
    @discord.ui.button(label="◀️ Voltar", style=discord.ButtonStyle.secondary, emoji="◀️")
    async def back_to_main(self, interaction: discord.Interaction, button: discord.ui.Button):
        back_btn = BackButton()
        await back_btn.callback(interaction)

class SettingsDropdown(discord.ui.Select):
    def __init__(self, options):
        super().__init__(placeholder="📋 Selecione uma categoria de configurações...", options=options)
    
    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        
        if category == "dm_behavior":
            await self.show_dm_behavior(interaction)
        elif category == "performance":
            await self.show_performance(interaction)
        elif category == "events":
            await self.show_events(interaction)
        elif category == "security":
            await self.show_security(interaction)
        elif category == "view_all":
            await self.show_all_settings(interaction)
    
    async def show_dm_behavior(self, interaction):
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)
        
        embed = discord.Embed(
            title="🤖 Configurações de Comportamento DM",
            description="**Configure como o bot se comporta ao enviar DMs**\n\n"
                       "🎯 **Funcionalidades disponíveis:**\n"
                       "• **Auto Reply**: Resposta automática a mensagens recebidas\n"
                       "• **Digitando**: Simular digitação antes de enviar mensagens\n"
                       "• **Reações**: Adicionar reações automáticas às mensagens\n"
                       "• **Fixar**: Fixar mensagens importantes automaticamente",
            color=discord.Color.green()
        )
        
        view = DMBehaviorPanel(settings)
        await interaction.response.edit_message(embed=embed, view=view)
    
    async def show_performance(self, interaction):
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)
        
        embed = discord.Embed(
            title="⚡ Configurações de Performance",
            description="**Otimize a performance e velocidade do bot**\n\n"
                       "🚀 **Configurações de velocidade:**\n"
                       "• **Cooldown**: Tempo entre envios de DM\n"
                       "• **Rate Limiting**: Controle de taxa de envio\n"
                       "• **Otimizações**: Melhorias de performance",
            color=discord.Color.yellow()
        )
        
        embed.add_field(
            name="⏱️ Configuração Atual",
            value=f"**Cooldown**: `{settings.get('dm_cooldown', 3)} segundos`\n"
                  f"**Status**: {'🟢 Otimizado' if settings.get('dm_cooldown', 3) >= 3 else '🟡 Rápido' if settings.get('dm_cooldown', 3) >= 1 else '🔴 Muito Rápido'}",
            inline=False
        )
        
        view = PerformancePanel()
        await interaction.response.edit_message(embed=embed, view=view)
    
    async def show_events(self, interaction):
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)
        
        embed = discord.Embed(
            title="🎯 Configurações de Eventos",
            description="**Configure quais eventos o bot deve monitorar**\n\n"
                       "📡 **Tipos de eventos:**\n"
                       "• **Mensagens**: Monitora mensagens enviadas/recebidas\n"
                       "• **Voz**: Monitora eventos de canal de voz\n"
                       "• **Presença**: Monitora status de usuários",
            color=discord.Color.purple()
        )
        
        view = EventsPanel(settings)
        await interaction.response.edit_message(embed=embed, view=view)
    
    async def show_security(self, interaction):
        embed = discord.Embed(
            title="🛡️ Configurações de Segurança",
            description="**Configurações avançadas de segurança**\n\n"
                       "🔒 **Recursos de proteção:**\n"
                       "• **Anti-spam**: Proteção contra spam\n"
                       "• **Rate limiting**: Controle de taxa\n"
                       "• **Whitelist**: Lista de usuários permitidos\n"
                       "• **Logs de segurança**: Monitoramento de atividades",
            color=discord.Color.red()
        )
        
        view = SecurityPanel()
        await interaction.response.edit_message(embed=embed, view=view)
    
    async def show_all_settings(self, interaction):
        with open('config/settings.yaml', 'r') as f:
            settings = yaml.safe_load(f)
        
        embed = discord.Embed(
            title="📋 Todas as Configurações",
            description="**Visualização completa de todas as configurações**",
            color=discord.Color.blue()
        )
        
        # Criar string formatada com todas as configurações
        config_text = "```yaml\n"
        for key, value in settings.items():
            if key != '_':  # Skip internal keys
                config_text += f"{key}: {value}\n"
        config_text += "```"
        
        embed.add_field(
            name="🔧 Configurações Atuais",
            value=config_text,
            inline=False
        )
        
        view = AllSettingsPanel()
        await interaction.response.edit_message(embed=embed, view=view)

# Variável global para controlar o sistema
system_running = False
dm_tasks = []

class StartButton(discord.ui.Button):
    def __init__(self, emoji="🚀"):
        super().__init__(label="Iniciar Sistema", style=discord.ButtonStyle.success, emoji=emoji)

    async def callback(self, interaction: discord.Interaction):
        global system_running, dm_tasks
        
        try:
            # Verificar se já está rodando
            if system_running:
                embed = discord.Embed(
                    title="⚠️ Sistema já está rodando",
                    description="O sistema já está em execução!"
                )
                buttons = discord.ui.View()
                buttons.add_item(StopButton())
                buttons.add_item(ViewLogsButton())
                buttons.add_item(BackButton())
                await interaction.response.edit_message(embed=embed, view=buttons)
                return
            
            # Verificar se há tokens disponíveis
            with open('config/tokens.txt', 'r') as f:
                tokens = [token.strip() for token in f.readlines() if token.strip()]
            
            if not tokens:
                embed = discord.Embed(
                    title="❌ Nenhum Token Encontrado",
                    description="🔑 **Nenhum token configurado!**\n\n"
                               "📝 **Para adicionar tokens:**\n"
                               "1. Use o botão **Tokens** no painel\n"
                               "2. Clique em **Adicionar**\n"
                               "3. Cole seu token do self-bot\n\n"
                               "⚠️ **Importante:** Use apenas tokens de contas suas!"
                )
                buttons = discord.ui.View()
                buttons.add_item(TokenButton())
                buttons.add_item(BackButton())
                await interaction.response.edit_message(embed=embed, view=buttons)
                return
            
            # Verificar validade dos tokens antes de iniciar
            valid_tokens = []
            invalid_tokens = []
            
            embed_loading = discord.Embed(
                title="🔍 Verificando Tokens...",
                description="Validando tokens antes de iniciar o sistema...",
                color=discord.Color.yellow()
            )
            await interaction.response.send_message(embed=embed_loading, ephemeral=True)
            
            for i, token in enumerate(tokens):
                try:
                    # Verificar formato básico primeiro
                    user_id = get_id(token)
                    
                    # Atualizar progresso
                    progress = f"Verificando token {i+1}/{len(tokens)}: {user_id}"
                    embed_loading.description = progress
                    await interaction.edit_original_response(embed=embed_loading)
                    
                    # Validar via API
                    if validate_token_api(token):
                        valid_tokens.append(token)
                        stats.add_log(f"✅ Token válido: {user_id}")
                    else:
                        invalid_tokens.append(token[:20])
                        stats.add_log(f"❌ Token inválido: {user_id}")
                        
                except Exception as e:
                    invalid_tokens.append(token[:20])
                    stats.add_log(f"❌ Token com erro: {token[:20]} - {str(e)}")
                
                # Pequeno delay para não sobrecarregar a API
                await asyncio.sleep(0.5)
            
            if not valid_tokens:
                embed = discord.Embed(
                    title="❌ Tokens Inválidos",
                    description="🚫 **Todos os tokens são inválidos!**\n\n"
                               "🔧 **Possíveis soluções:**\n"
                               "• Verifique se os tokens estão corretos\n"
                               "• Tokens podem ter expirado\n"
                               "• Contas podem estar suspensas\n\n"
                               "📝 **Adicione tokens válidos para continuar**"
                )
                buttons = discord.ui.View()
                buttons.add_item(TokenButton())
                buttons.add_item(BackButton())
                await interaction.edit_original_response(embed=embed, view=buttons)
                return
            
            # Iniciar o sistema
            system_running = True
            stats.add_log(f"🚀 Iniciando sistema com {len(valid_tokens)} tokens válidos")
            
            # Mostrar progresso de inicialização
            embed = discord.Embed(
                title="🚀 Iniciando Sistema...",
                description=f"🔄 **Conectando self-bots...**\n\n"
                           f"✅ **Tokens válidos:** {len(valid_tokens)}\n"
                           f"❌ **Tokens inválidos:** {len(invalid_tokens)}\n\n"
                           f"⏳ **Aguarde a conexão...**"
            )
            
            await interaction.edit_original_response(embed=embed, view=discord.ui.View())
            
            # Iniciar tarefas de DM para cada token válido
            for token in valid_tokens:
                task = asyncio.create_task(start_dm_system(token))
                dm_tasks.append(task)
                await asyncio.sleep(1)  # Delay entre conexões
                
            # Aguardar um pouco para verificar se os processos iniciaram
            await asyncio.sleep(5)
            
            embed = discord.Embed(
                title="✅ Sistema Iniciado com Sucesso!",
                description=f"🎯 **Self-bots conectados e funcionando**\n\n"
                           f"🔑 **Tokens ativos:** {len(valid_tokens)}\n"
                           f"📊 **Status:** Sistema em execução\n"
                           f"🚀 **Pronto para enviar DMs!**\n\n"
                           f"📋 **Use 'Ver Logs' para monitorar atividades**",
                color=0x00ff00
            )
            
            if invalid_tokens:
                embed.add_field(
                    name="⚠️ Tokens Ignorados",
                    value=f"**{len(invalid_tokens)}** tokens inválidos foram ignorados",
                    inline=False
                )
            
            buttons = discord.ui.View()
            buttons.add_item(StopButton())
            buttons.add_item(ViewLogsButton())
            buttons.add_item(BackButton())
            
            await interaction.edit_original_response(embed=embed, view=buttons)

        except Exception as e:
            stats.add_log(f"❌ Erro crítico ao iniciar sistema: {str(e)}")
            embed = discord.Embed(
                title="❌ Erro Crítico",
                description=f"🚫 **Falha ao iniciar o sistema**\n\n"
                           f"**Erro:** `{str(e)}`\n\n"
                           f"🔧 **Tente:**\n"
                           f"• Verificar se há tokens válidos\n"
                           f"• Reiniciar o bot\n"
                           f"• Verificar logs para mais detalhes"
            )
            
            buttons = discord.ui.View()
            buttons.add_item(BackButton())
            
            if not interaction.response.is_done():
                await interaction.response.edit_message(embed=embed, view=buttons)
            else:
                await interaction.edit_original_response(embed=embed, view=buttons)

class BotController(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.all())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()

client = BotController()

@client.event
async def on_ready():
    global emoji_manager
    stats.add_log(f'🤖 Bot Controller está online como {client.user.name}')
    
    # Verificar dependências essenciais
    try:
        import discum
        stats.add_log(f'✅ Dependência discum encontrada - versão OK')
    except ImportError:
        stats.add_log(f'❌ ERRO: Dependência discum não encontrada!')
        stats.add_log(f'🔧 Execute: pip install discum')
    
    # Verificar arquivos de configuração
    config_files = ['config/tokens.txt', 'config/settings.yaml', 'config/message.txt']
    for file_path in config_files:
        if os.path.exists(file_path):
            stats.add_log(f'✅ Arquivo encontrado: {file_path}')
        else:
            stats.add_log(f'⚠️ Arquivo ausente: {file_path}')
    
    # Configurar gerenciador de emojis
    if client.guilds:
        emoji_manager = EmojiManager(client.guilds[0])  # Usar o primeiro servidor
        await emoji_manager.setup_all_emojis()
        stats.add_log(f'🎨 Emojis customizados configurados para {client.guilds[0].name}')
    else:
        stats.add_log("⚠️ Bot não está em nenhum servidor para criar emojis customizados")
    
    # Verificar tokens existentes
    try:
        with open('config/tokens.txt', 'r') as f:
            tokens = [token.strip() for token in f.readlines() if token.strip()]
        
        if tokens:
            stats.add_log(f'🔑 {len(tokens)} tokens encontrados no sistema')
            
            # Verificar validade básica dos tokens
            valid_count = 0
            for token in tokens:
                try:
                    user_id = get_id(token)
                    valid_count += 1
                except:
                    pass
            
            stats.add_log(f'✅ {valid_count} tokens aparentam estar válidos')
            if valid_count != len(tokens):
                stats.add_log(f'⚠️ {len(tokens) - valid_count} tokens podem estar inválidos')
        else:
            stats.add_log(f'⚠️ Nenhum token configurado - adicione tokens para usar o sistema')
            
    except Exception as e:
        stats.add_log(f'❌ Erro ao verificar tokens: {str(e)}')
    
    # Iniciar thread de atualização automática
    update_thread = threading.Thread(target=auto_update_display, daemon=True)
    update_thread.start()
    
    stats.add_log(f'🚀 Sistema pronto para uso! Use /painel para começar')

def auto_update_display():
    """Thread para atualizar o display automaticamente a cada 5 segundos"""
    while True:
        time.sleep(5)
        stats.update_title()

@client.event
async def on_interaction(interaction):
    """Handler para as interações dos componentes do painel"""
    if interaction.type == discord.InteractionType.component:
        custom_id = interaction.data.get('custom_id')
        
        # Verificar permissões
        if not check_permission(interaction.user.id):
            await interaction.response.send_message("Você não tem permissão para usar esta função.", ephemeral=True)
            return
        
        if custom_id == "manage_tokens":
            token_button = TokenButton()
            await token_button.callback(interaction)
        
        elif custom_id == "manage_message":
            message_button = MessageButton()
            await message_button.callback(interaction)
        
        elif custom_id == "manage_settings":
            settings_button = SettingsButton()
            await settings_button.callback(interaction)
        
        elif custom_id == "start_system":
            start_button = StartButton()
            await start_button.callback(interaction)
        
        elif custom_id == "stop_system":
            stop_button = StopButton()
            await stop_button.callback(interaction)
        
        elif custom_id == "view_logs":
            logs_button = ViewLogsButton()
            await logs_button.callback(interaction)
        
        elif custom_id == "advanced_options":
            selected_value = interaction.data.get('values', [None])[0]
            
            if selected_value == "manage_permissions":
                if not is_owner(interaction.user.id):
                    await interaction.response.send_message("Apenas donos podem gerenciar permissões.", ephemeral=True)
                    return
                perm_button = PermissionButton()
                await perm_button.callback(interaction)
            
            elif selected_value == "detailed_stats":
                await show_detailed_stats(interaction)
            
            elif selected_value == "advanced_settings":
                await show_advanced_settings_editor(interaction)

async def show_detailed_stats(interaction):
    """Mostrar estatísticas detalhadas do sistema"""
    embed = discord.Embed(
        title="📊 Estatísticas Detalhadas do Sistema",
        color=discord.Color.green()
    )
    
    # Estatísticas gerais
    embed.add_field(
        name="📈 Estatísticas Gerais",
        value=f"**DMs Enviadas**: `{stats.dms_deliver}`\n"
              f"**Usuários Capturados**: `{stats.dms_captured}`\n"
              f"**Logs Registrados**: `{len(stats.log_messages)}`\n"
              f"**Usuários em DM**: `{len(stats.dms_sends)}`",
        inline=False
    )
    
    # Informações do sistema
    with open('config/tokens.txt', 'r') as f:
        token_count = len(f.readlines())
    
    ping = round(client.latency * 1000)
    
    embed.add_field(
        name="🖥️ Sistema",
        value=f"**Tokens Ativos**: `{token_count}`\n"
              f"**Ping do Bot**: `{ping}ms`\n"
              f"**Status**: {'🟢 Online' if ping < 200 else '🟡 Instável' if ping < 500 else '🔴 Alto Delay'}\n"
              f"**Sistema Rodando**: `{'✅ Sim' if system_running else '❌ Não'}`",
        inline=False
    )
    
    # Logs recentes
    recent_logs = stats.log_messages[-5:] if stats.log_messages else ["Nenhum log disponível"]
    embed.add_field(
        name="📋 Logs Recentes",
        value="```\n" + "\n".join(recent_logs) + "\n```",
        inline=False
    )
    
    view = discord.ui.View()
    view.add_item(BackButton())
    
    await interaction.response.edit_message(embed=embed, view=view, components=[])

async def show_advanced_settings_editor(interaction):
    """Mostrar editor avançado de configurações"""
    modal = AdvancedSettingsModal()
    await interaction.response.send_modal(modal)

def check_permission(user_id):
    try:
        with open('data/config.json', 'r') as f:
            config = json.load(f)
        
        with open('data/perm.json', 'r') as f:
            perm = json.load(f)
        
        return user_id == config.get('ownerID') or str(user_id) in perm.get('owners', []) or str(user_id) in perm.get('permitted', [])
    except Exception as e:
        print(f"Erro ao verificar permissões: {e}")
        return False

def is_owner(user_id):
    try:
        with open('data/config.json', 'r') as f:
            config = json.load(f)
        
        with open('data/perm.json', 'r') as f:
            perm = json.load(f)
        
        return user_id == config.get('ownerID') or str(user_id) in perm.get('owners', [])
    except Exception as e:
        print(f"Erro ao verificar se é dono: {e}")
        return False

@client.tree.command(name="setup_emojis", description="Configurar emojis customizados para o painel")
async def setup_emojis(interaction: discord.Interaction):
    # Verificar se o usuário tem permissão
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Apenas donos podem configurar emojis customizados.", ephemeral=True)
        return
    
    global emoji_manager
    
    if not emoji_manager:
        emoji_manager = EmojiManager(interaction.guild)
    
    await interaction.response.send_message("Configurando emojis customizados...", ephemeral=True)
    
    # Configurar todos os emojis
    await emoji_manager.setup_all_emojis()
    
    embed = discord.Embed(
        title="✅ Emojis Configurados",
        description="Todos os emojis customizados foram configurados com sucesso!\n\n**Emojis criados:**",
        color=discord.Color.green()
    )
    
    for name, emoji in emoji_manager.created_emojis.items():
        embed.add_field(name=name.title(), value=emoji, inline=True)
    
    await interaction.edit_original_response(content="", embed=embed)

@client.tree.command(name="painel", description="Painel de controle do bot")
async def painel(interaction: discord.Interaction):
    # Verificar se o usuário tem permissão
    if not check_permission(interaction.user.id):
        await interaction.response.send_message("Você não tem permissão para usar este comando.", ephemeral=True)
        return

    with open('config/tokens.txt', 'r') as f:
        token_count = len(f.readlines())

    # Obter informações do sistema
    ping = round(client.latency * 1000)
    status_color = "Online" if ping < 200 else "Instável" if ping < 500 else "Alto Delay"
    
    # Embed moderno sem emojis
    embed = discord.Embed(
        title="Painel de Controle do Bot",
        description=f"Gerencie o sistema de controle {interaction.user.mention}",
        color=discord.Color.blue()
    )
    
    # Adicionar informações do sistema
    embed.add_field(
        name="Status do Sistema",
        value=f"**Status**: {status_color}\n**Ping**: {ping}ms\n**Tokens**: {token_count}",
        inline=True
    )
    
    embed.add_field(
        name="Estatísticas",
        value=f"**DMs Enviadas**: {stats.dms_deliver}\n**Usuários**: {stats.dms_captured}\n**Logs**: {len(stats.log_messages)}",
        inline=True
    )
    
    embed.add_field(
        name="Sistema Ativo",
        value=f"**Status**: {'Rodando' if system_running else 'Parado'}\n**Uptime**: Ativo\n**Memoria**: Normal",
        inline=True
    )
    
    if interaction.user.avatar:
        embed.set_thumbnail(url=interaction.user.avatar.url)
    
    embed.set_footer(text="Sistema de Controle - Desenvolvido pela Equipe")

    # Usar o sistema de view moderno
    view = ModernPainelView(is_owner(interaction.user.id))
    await interaction.response.send_message(
        embed=embed,
        view=view,
        ephemeral=True
    )
import json

try:
    with open('token.json', 'r') as f:
        token_config = json.load(f)
    
    if not token_config.get('token') or token_config['token'] == "SEU_TOKEN_AQUI":
        print("❌ Token não configurado! Edite o arquivo token.json e adicione seu token do bot.")
        exit(1)
        
    client.run(token_config['token'])
except FileNotFoundError:
    print("❌ Arquivo token.json não encontrado! Crie o arquivo e adicione seu token.")
    exit(1)
except Exception as e:
    print(f"❌ Erro ao carregar token: {e}")
    exit(1)